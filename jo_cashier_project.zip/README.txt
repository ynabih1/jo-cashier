جو كاشير - Electron project ready for Windows EXE build
-------------------------------------------------------

هذا المجلد يحتوي مشروع Electron جاهز. لبناء ملف EXE على GitHub Actions اتبع التالي:

1) أنشئ مستودع جديد على GitHub وادفع (push) محتوى هذا المجلد إليه.
2) ضمن المجلد .github/workflows/ موجود ملف build-windows.yml الذي يقوم ببناء EXE.
3) فعّل GitHub Actions ثم شغّل Workflow يدويًا أو عند كل دفع (push).
4) بعد اكتمال العمل ستجد artifact يحتوي EXE جاهز للتحميل.

إذا لا تملك كمبيوتر، هذه الطريقة تسمح ببناء EXE تلقائياً على GitHub.

ملاحظات:
- تحتاج إلى ملف dist/ داخل app/www/ يحتوي واجهة الويب (HTML/CSS/JS). إن لم يكن، التطبيق سيعمل لكن بصفحة بسيطة.
- يمكنك تعديل package.json أو أي ملف قبل البناء.
